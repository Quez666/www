<?php
/**
 * Cabecera de todas las paginas de la web
 */
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<META http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="style.css" type="text/css" rel="stylesheet">
	<script type="text/javascript" src="javascript.js"></script>
</head>

<body topmargin="0" marginheight="0">
