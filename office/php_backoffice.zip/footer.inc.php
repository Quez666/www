<?php
/**
 * Contiene el pie de pagina que aparece en todas las paginas una vez estas
 * validado
 */

?>
<div class='roundTop fixed' style='width:760px;padding:10px;background-color:#d0d0d0;text-align:center;margin-top:30px'>
	<a href="http://www.lawebdelprogramador.com" target="_blank">http://www.lawebdelprogramador.com</a>
</div>

</body>
</html>
